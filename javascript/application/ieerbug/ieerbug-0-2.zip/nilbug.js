function IEerBug(init){

window.console = new NilBugConsole();

function NilBugConsole()
{
	this.firebug = "0.4";

	this.logRelay = function()
	}

	this.log = function()
	{
	}

	this.logMessage = function()
	{
	}

	this.logAssert = function()
	{
	}
	
	this.debug = function()
	{
	}
	
	this.info = function()
	{
	}
	
	this.warn = function()
	{
	}
	
	this.error = function()
	{
	}

	this.fail = function()
	{
	}
	
	this.assert = function()
	{
	}

	this.assertEquals = function()
	{
	}

	this.assertNotEquals = function()
	{
	}	

	this.assertGreater = function()
	{
	}	

	this.assertNotGreater = function()
	{
	}	

	this.assertLess = function()
	{
	}	

	this.assertNotLess = function()
	{
	}	

	this.assertContains = function()
	{
	}	

	this.assertNotContains = function()
	{
	}	

	this.assertTrue = function()
	{
	}	

	this.assertFalse = function()
	{
	}	

	this.assertNull = function()
	{
	}	

	this.assertNotNull = function()
	{
	}	

	this.assertUndefined = function()
	{
	}	

	this.assertNotUndefined = function()
	{
	}	

	this.assertInstanceOf = function()
	{
	}	

	this.assertNotInstanceOf = function()
	{
	}	

	this.assertTypeOf = function()
	{
	}	

	this.assertNotTypeOf = function()
	{
	}	

	this.group = function()
	{
	}
	
	this.groupEnd = function()
	{
	}
	
	this.time = function()
	{
	}
	
	this.timeEnd = function()
	{
	}
	
	this.count = function()
	{
	}
	
	this.trace = function()
	{
	}
}
}