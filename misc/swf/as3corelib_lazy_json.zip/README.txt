as3corelib JSON parser improved.
  see: http://as3corelib.googlecode.com/files/as3corelib-.92.1.zip

Added following function.
  - allow trailing comma in 'object' and 'array'.
    (ex) { "a": 3, "b": 3, }
         [ 1, 2, 3, ]

  - skip 'object' key "".
    (ex) { a: 3, b: 3 }

  - allow .3
    (ex) { "a": .3 }
