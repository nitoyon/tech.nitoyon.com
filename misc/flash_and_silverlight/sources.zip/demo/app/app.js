Import("System.Windows.Application")
Import("System.Windows.Controls.Canvas") 
Import("System.Windows.Browser.HtmlPage")

function App() {
   this.scene = Application.Current.LoadRootVisual(new Canvas(), "app.xaml")
}

App.prototype.start = function() {
  this.scene.findName("myButton").MouseLeftButtonDown += function(sender){
	HtmlPage.Window.Invoke("clicked");
  }
}

var app = new App
app.start()
