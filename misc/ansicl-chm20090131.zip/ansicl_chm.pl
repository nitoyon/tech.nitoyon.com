
use strict;

my $TOC_TMPL_START = <<EOF;
<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML//EN">
<HTML>
<HEAD>
<meta name="GENERATOR" content="Microsoft&reg; HTML Help Workshop 4.1">
<!-- Sitemap 1.0 -->
</HEAD><BODY>
<OBJECT type="text/site properties">
	<param name="ImageType" value="Folder">
</OBJECT>
<UL>
	<LI> <OBJECT type="text/sitemap">
		<param name="Name" value="ANSI Common Lisp">
		<param name="Local" value="ansicl.htm">
		</OBJECT>
EOF

my $TOC_TMPL_END = "</UL>\n</BODY></HTML>";

my $INDEX_TMPL_START = <<EOF;
<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML//EN">
<HTML>
<HEAD>
<meta name="GENERATOR" content="Microsoft&reg; HTML Help Workshop 4.1">
<!-- Sitemap 1.0 -->
</HEAD><BODY>
<UL>
EOF
my $INDEX_TMPL_END = "</UL>\n</BODY></HTML>";

# start
#&create_toc();
&create_index();

sub create_toc{
	open my $file, "<", "meta/tableofc.htm" or die $!;
	my $contents = join('', <$file>);
	close($file);

	$contents=~s!.*Table of Contents</h3>!!si;
	$contents=~s!</table>.*!!si;


	my $out = $TOC_TMPL_START;
	my $index = 1;
	for my $line(split(/\n/g, $contents)){
		my $indent = "\t" x $index;

		if ($line=~m!([0-9\.]+) <a href="\.\./([^"]+)"[^>]+>([^<]+)!i){
			my ($num, $url, $title) = ($1, $2, $3);
			$out .= $indent . <<EOL;
<LI> <OBJECT type="text/sitemap"><param name="Name" value="$num $title"><param name="Local" value="$url"></OBJECT>
EOL
		}

		if ($line=~m!</ul>!){
			$index--;
			$indent = "\t" x $index;
			$out .= "$indent</ul>\n";
		} elsif ($line=~m!<ul>!i){
			$out .= "$indent<ul>\n";
			$index++;
		}
	}
	$out .= $TOC_TMPL_END;

	open my $f, '>', "toc.hhc" or die;
	print $f $out;
	close $f;
}


sub create_index{
	my $out = $INDEX_TMPL_START;
	my @files = glob("indexcha/*.htm");

	for my $file(@files){
		open my $f, "<", $file or die;
		my $contents = join('', <$f>);
		close $f;

		$contents=~s!.*</h1>!!si;
		$contents=~s!</table>.*!!si;

		my $index = 1;
		my $f = 0;
		for my $line(split(/\n/g, $contents)){
			if ($line=~/^<p/i && $index == 2){
				$f = 0;
				$index = 1;
				$out .= "</ul>\n";
			}
			if ($line=~/^<br>&nbsp;/i && $index == 1){
				$out .= qq|\t\t</OBJECT>\n| if $f;
				$f = 0;
				$index = 2;
				$out .= "\t<UL>\n";
			}
			
			my $indent1 = "\t" x $index;
			my $indent2 = "\t" x ($index + 1);
			if ($line=~m!<b>([^<]+)</b> +(.*)!i){
				my ($name, $rest) = ($1, $2);
				$name=~s/&/&amp;/ unless $name=~/&[^;]+;/; # &body -> &amp;body
				$out .= qq|$indent2</OBJECT>\n| if $f;
				$out .= qq|$indent1<LI> <OBJECT type="text/sitemap">\n$indent2<param name="Name" value="$name">\n|;
				unless ($rest=~/<a /i){
					$out .= qq|$indent2<param name="Name" value="NO DATA">\n$indent2<param name="Local" value="nodata.htm">\n|;
					next;
				}
				$line = $rest;
			}

			if ($line=~m!<a href="\.\./([^"]+)"[^>]+>([^<]+)<!i){
				my ($url, $name) = ($1, $2);
				$name=~s/&/&amp;/ unless $name=~/&[^;]+;/; # &body -> &amp;body
				$url=~s!/!\\!g;
				$out .= qq|$indent2<param name="Name" value="$name">\n$indent2<param name="Local" value="$url">\n|;
				$f = 1;
			}
		}
		$out .= qq|\t\t</OBJECT>\n| if $f;
		$out .= "\t</UL>\n" if $index eq 2;
	}
	$out .= $INDEX_TMPL_END;

	open my $f, '>', "index.hhk" or die;
	print $f $out;
	close $f;
}
