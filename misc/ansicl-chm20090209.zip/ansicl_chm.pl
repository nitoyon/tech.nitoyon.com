use strict;
use File::Basename;
use Data::Dumper;

my $TOC_TMPL_START = <<EOF;
<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML//EN">
<HTML>
<HEAD>
<meta name="GENERATOR" content="Microsoft&reg; HTML Help Workshop 4.1">
<!-- Sitemap 1.0 -->
</HEAD><BODY>
<OBJECT type="text/site properties">
	<param name="ImageType" value="Folder">
</OBJECT>
EOF

my $TOC_TMPL_END = "</BODY></HTML>";

my $INDEX_TMPL_START = <<EOF;
<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML//EN">
<HTML>
<HEAD>
<meta name="GENERATOR" content="Microsoft&reg; HTML Help Workshop 4.1">
<!-- Sitemap 1.0 -->
</HEAD><BODY>
<UL>
EOF
my $INDEX_TMPL_END = "\n</UL>\n</BODY></HTML>";

# start
&create_toc();
#&create_index();

sub create_toc{
	my $toc = { url => 'ansicl.htm', title => 'ANSI Common Lisp', children => {} };
	&parse_link('ansicl.htm', $toc->{children});
	open my $f, '>', "toc.hhc" or die;
	print $f $TOC_TMPL_START . &toc_html($toc) . $TOC_TMPL_END;
	close $f;
}

sub parse_link{
	my $url = shift;
	my $parent = shift;
	my $dir = dirname($url);
	open my $fh, "<", $url or die $! . " $url";
	my $contents = join('', <$fh>);
	close($fh);

	my @match = ($contents =~m!((?:[0-9]+\.)*[0-9]+)&nbsp;&nbsp;<a href="(?:\.\./)?([^"]+)"[^>]+>([^>]+)</a><(?:nobr|br)>!sig);
	while(@match){
		my $num = shift @match;
		my $url = shift @match;
		my $title = shift @match;
		$url = "$dir/$url" unless $url=~m!/!;
		$parent->{$num} = { url => $url, num => $num, title => $title, children => {} };
		&parse_link($url, $parent->{$num}->{children});
	}
	return $parent;
}

sub toc_html{
	my $toc = shift;
	my $index = shift;
	my $i = 1;

	my $indent = "\t" x $index;
	my $str = "$indent<UL>\n";
	my $title = $toc->{'title'};
	$title=~s/&/&amp;/g;
	$title=~s/"/&quote;/g;
	$str .= qq|$indent\t<LI><OBJECT type="text/sitemap">\n|;
	$str .= qq|$indent\t\t<param name="Name" value="| . $toc->{'num'} . ' ' . $title . qq|">\n|;
	$str .= qq|$indent\t\t<param name="Local" value="| . $toc->{'url'} . qq|">\n|;
	$str .= qq|$indent\t\t</OBJECT>\n|;

	my $num = $toc->{'num'};
	$num .= "." if $num ne "";
	while($toc->{'children'}->{"$num$i"}){
		$str .= &toc_html($toc->{'children'}->{"$num$i"}, $index + 1);
		$i++;
	}

	$str .= qq|$indent</UL>\n|;
	return $str;
}

sub create_index{
	my $out = $INDEX_TMPL_START;
	my @files = glob("indexcha/*.htm");

	for my $file(@files){
		open my $f, "<", $file or die;
		my $contents = join('', <$f>);
		close $f;

		$contents=~s!.*</h1>!!si;
		$contents=~s!</table>.*!!si;

		my $index = 1;
		my $f = 0;
		for my $line(split(/\n/g, $contents)){
			if ($line=~/^<p/i && $index == 2){
				$f = 0;
				$index = 1;
				$out .= "</ul>\n";
			}
			if ($line=~/^<br>&nbsp;/i && $index == 1){
				$out .= qq|\t\t</OBJECT>\n| if $f;
				$f = 0;
				$index = 2;
				$out .= "\t<UL>\n";
			}
			
			my $indent1 = "\t" x $index;
			my $indent2 = "\t" x ($index + 1);
			if ($line=~m!<b>([^<]+)</b> +(.*)!i){
				my ($name, $rest) = ($1, $2);
				$name=~s/&/&amp;/ unless $name=~/&[^;]+;/; # &body -> &amp;body
				$out .= qq|$indent2</OBJECT>\n| if $f;
				$out .= qq|$indent1<LI> <OBJECT type="text/sitemap">\n$indent2<param name="Name" value="$name">\n|;
				unless ($rest=~/<a /i){
					$out .= qq|$indent2<param name="Name" value="NO DATA">\n$indent2<param name="Local" value="nodata.htm">\n|;
					next;
				}
				$line = $rest;
			}

			if ($line=~m!<a href="\.\./([^"]+)"[^>]+>([^<]+)<!i){
				my ($url, $name) = ($1, $2);
				$name=~s/&/&amp;/ unless $name=~/&[^;]+;/; # &body -> &amp;body
				$url=~s!/!\\!g;
				$out .= qq|$indent2<param name="Name" value="$name">\n$indent2<param name="Local" value="$url">\n|;
				$f = 1;
			}
		}
		$out .= qq|\t\t</OBJECT>\n| if $f;
		$out .= "\t</UL>\n" if $index eq 2;
	}
	$out .= $INDEX_TMPL_END;

	open my $f, '>', "index.hhk" or die;
	print $f $out;
	close $f;
}
